#pragma once

#include "ButtonInterface.h"

class BUTTON : public BUTTON_INTERFACE
{
private:
	int start_gh[3];
	int stop_gh[3];


	enum State{
		start,
		stop,
	}state;

public:
	BUTTON();
	virtual void OnPush() override;
};

