#include "pch.h"
#include "gameControl.h"

//-----------�R���X�g���N�^---------------//
SCORE::SCORE()
{
	//�摜�ǂݍ���
	if(-1==LoadDivGraph("images/board1.png",5,1,5,170,150/5,gh_board)){
		MSG("�G���[����");
	}
	if(-1==LoadDivGraph("images/number.png",10,10,1,19,27,gh_number)){
		MSG("�G���[����");
	}

	high_score	= 0;
	score	= 0;
	graze	= 0;
	life	= 5;
	item	= 0;
	
	comment_x	= 705;
	
	comment_y	= 115;
}


//-----------Draw�֐�---------------//
void SCORE::Draw()
{
	char buf[100];
	int num;

	//�X�R�A�{�[�h�̕����`��
	/*
	DrawGraph(SCORE_X, 10, gh_board[0], true);
	DrawGraph(SCORE_X, 70, gh_board[1], true);
	DrawGraph(SCORE_X, 140, gh_board[2], true);
	DrawGraph(SCORE_X, 170, gh_board[3], true);
	DrawGraph(SCORE_X, 200, gh_board[4], true);
	*/
	//int Cr = GetColor( 255 , 255 , 255 ) ;
	/*
	DrawString(42, 18 ,"SCORE", Cr ) ;
	DrawString(155, 18 ,"GRAZE", Cr ) ;
	DrawString(235, 18 ,"POWER", Cr ) ;
	DrawString(315, 18 ,"ITEM", Cr ) ;
	DrawString(395, 18 ,"HIGH SCORE", Cr ) ;
	*/
	
	int Cr = GetColor( 0 , 0 , 0 ) ;
	DrawString(comment_x, comment_y ,"SCORE", Cr ) ;
	DrawString(comment_x, comment_y+23,"GRAZE", Cr ) ;
	DrawString(comment_x, comment_y+46,"LIFE", Cr ) ;
	DrawString(comment_x, comment_y+69,"POWER", Cr ) ;
	//DrawString(comment_x, comment_y+92,"HIGH SCORE", Cr ) ;

	/*//�n�C�X�R�A�`��
	num	= sprintf(buf, "%d", high_score);
	for(int i=0;i<num;i++){
		DrawRotaGraph(500+i*19, 27, 0.7, 0, gh_number[(buf[i])-'0'], true);
	}*/

	//�X�R�A�`��
	num	= sprintf(buf, "%d", score);
	for(int i=0;i<num;i++){
		DrawRotaGraph(comment_x+80+i*10, comment_y+8 , 1.0 , 0, gh_number[(buf[i])-'0'], true);
	}

	//�O���C�Y�`��
	num	= sprintf(buf, "%d", graze);
	for(int i=0;i<num;i++){
		DrawRotaGraph(comment_x+80+i*10, comment_y+31 , 1.0 , 0, gh_number[(buf[i])-'0'], true);
	}

	//���C�t�`��
	num	= sprintf(buf, "%d", life);
	for(int i=0;i<num;i++){
		DrawRotaGraph(comment_x+80+i*10, comment_y+54 , 1.0 , 0, gh_number[(buf[i])-'0'],true);
	}

	//�A�C�e���`��
	num	= sprintf(buf, "%d", item);
	for(int i=0;i<num;i++){
		DrawRotaGraph(comment_x+80+i*10, comment_y+77 , 1.0, 0, gh_number[(buf[i])-'0'],true);
	}
}


//-----------SetScore�֐�---------------//
void SCORE::SetScore(SCOREDATA data, int val)
{
	switch(data){
		case HIGH_SCORE:
			high_score	+= val;
			break;

		case CURRENT_SCORE:
			score	+= val;
			break;
		
		case GRAZE_SCORE:
			graze	+= val;
			break;
		
		case LIFE_SCORE:
			life	= val;
			break;

		case POWER_SCORE:
			item	+= val;
			break;
	}
}


//-----------GetScore�֐�---------------//
int SCORE::GetScore(SCOREDATA data)
{
	switch(data){
		case HIGH_SCORE:
			return high_score;
			break;

		case CURRENT_SCORE:
			return score;
			break;
		
		case GRAZE_SCORE:
			return graze;
			break;
		
		case LIFE_SCORE:
			return life;
			break;

		case POWER_SCORE:
			return life;
			break;
	}
	//�Y�����Ȃ�����-1��Ԃ�
	return -1;
}


//-----------All�֐�---------------//
void SCORE::All()
{
	Draw();
}
