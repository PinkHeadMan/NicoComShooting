#include "pch.h"
#include "gameControl.h"

//-----------�R���X�g���N�^---------------//
BUTTON::BUTTON()
{
	int gh_temp;
	int width ,height;
	gh_temp	= LoadGraph("images/button_start.png");
	GetGraphSize(gh_temp, &width, &height);


	width	/= 3;	//�摜���T�C�Y
	SetSize(width , height);

	//�摜�ǂݍ���
	if(-1==LoadDivGraph("images/button_start.png",3 ,3 ,1 , width ,height ,start_gh)){
		MSG("button_start.png���ǂݍ��߂܂���ł����B");
	}

	if(-1==LoadDivGraph("images/button_stop.png",3 ,3 ,1 , width ,height ,stop_gh)){
		MSG("button_stop.png���ǂݍ��߂܂���ł����B");
	}	


	DeleteGraph(gh_temp);

	state	= stop;
	SetGraph(stop_gh);
}


//-----------OnPush�֐�---------------//
void BUTTON::OnPush()
{
	GAME_CONTROL &gameControl = GAME_CONTROL::GetInstance();

	if(state == start){
		state	= stop;
		SetGraph(stop_gh);
		gameControl.Pause();
	}else{
		state	= start;
		SetGraph(start_gh);
		gameControl.Resume();
	}
}
