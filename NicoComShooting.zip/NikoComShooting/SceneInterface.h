#pragma once

#include<memory>

//-----------�N���X---------------//
class SCENE_INTERFACE
{
	public:
		virtual void All() = 0;
};

//class Control;