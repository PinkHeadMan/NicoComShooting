#pragma once

class BUTTON_INTERFACE
{
private:
	int x,y;
	int height,width;
	int gh[3];
	enum State
	{
		none,
		hover,
		push,
	}state;
	
	bool push_flag;	
	bool pushing_flag;	

public:
	BUTTON_INTERFACE();
	virtual void OnPush() = 0;
	void Update();
	void Draw();
	void SetSize(int x, int y);
	void SetGraph(const int (&gh)[3]);
	void SetPosition(int x, int y);

};

