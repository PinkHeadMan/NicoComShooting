#pragma once


class BAR_SOUND
{
private:
	int width,height;
	int gh;
	
	int bar_x;
	int bar_y;
	int bar_ix;
	int bar_iy;

	int color;
	int value;
	
	int MouseX;
	int MouseY;

	bool push_flag;
	bool pushing_flag;

	enum State
	{
		none,
		hover,
		push,
	}state;

public:
	BAR_SOUND();
	void Draw();
	void Update(int num, int *gh);
	void ChangeVolume(int num, int *gh);

	void SetPosition(int x, int y);

};

