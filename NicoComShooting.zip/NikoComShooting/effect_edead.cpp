#include "pch.h"
#include "gameControl.h"

int EFFECT_EDEAD::gh[3];

//-----------�R���X�g���N�^---------------//
EFFECT_EDEAD::EFFECT_EDEAD()
{
	x	= 0;	//������
	y	= 0;

	//�摜�ǂݍ���
	if(gh[0]==0){
		gh[0]	= LoadGraph("effect1.png");
		gh[1]	= LoadGraph("effect2.png");
		gh[2]	= LoadGraph("effect3.png");
	}
	//������������
	srand((unsigned int)time(nullptr));

	//������
	rad		= 0;
	rate	= 1;
	alpha	= 255;
	count	= 0;
	index	= 0;

	flag	= false;

}


//-----------Move�֐�---------------//
void EFFECT_EDEAD::Move(){
	if(flag){
		//���񂾂��p�x�ƓY���Z�b�g
		if(count==0){
			rad		= rand()%624/100;
			index	= rand()%3;
		}

		rate	= 0.5+count*0.05;
		alpha	= 255-255/30*count;
		count++;

		if(count==30){
			count	= 0;
			flag	= false;
		}
	}
}


//-----------Draw�֐�---------------//
void EFFECT_EDEAD::Draw(){
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
	DrawRotaGraph(x, y, rate, rad, gh[index], TRUE);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}


//-----------GetFlag�֐�---------------//
bool EFFECT_EDEAD::GetFlag()
{
	return flag;
}


//-----------SetFlag�֐�---------------//
void EFFECT_EDEAD::SetFlag(double x, double y)
{
	this->x	=x;
	this->y	=y;

	flag	= true;
}


//-----------All�֐�---------------//
void EFFECT_EDEAD::All()
{
	Move();
	Draw();
}
