#pragma once

class GRAZE
{
private:
	int gh;
	double x;
	double y;

	double rad;
	double rate;
	int alpha;

	int count;

	bool flag;

public:
	GRAZE();
	void Move();
	void Draw();
	void SetFlag(double x, double y);
	bool GetFlag();
	void All();
};