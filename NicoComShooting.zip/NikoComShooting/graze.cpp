#include "pch.h"
#include "gameControl.h"

//-----------�R���X�g���N�^---------------//
GRAZE::GRAZE()
{

	//������
	gh	= LoadGraph("images/graze.png");

	x	= 0;
	y	= 0;

	rad		= 0;
	rate	= 0;

	count	= 0;
	flag	= false;

	srand((unsigned)time(nullptr));
}


//-----------Move�֐�---------------//
void GRAZE::Move()
{
	//���񂾂��p�x�ݒ�
	if(count==0){
		rad	= rand()%628/100;
	}

	alpha	= 255-(255/20)*count;
	rate	= 1.0-0.05*count;
	
	x	+= cos(rad)*6;
	y	+= sin(rad)*6;

	count++;

	//�J�E���g20�܂œ���
	if(count==20){
		count	= 0;
		flag	= false;
	}
}


//-----------Draw�֐�---------------//
void GRAZE::Draw()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, alpha);
	DrawRotaGraph(x, y, rate, 1, gh, true);
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 255);
}


//-----------GetFlag�֐�---------------//
bool GRAZE::GetFlag()
{
	return flag;
}


//-----------SetFlag�֐�---------------//
void GRAZE::SetFlag(double x, double y)
{
	this->x	= x;
	this->y	= y;
	flag	= true;
}


//-----------All�֐�---------------//
void GRAZE::All()
{
	if(flag){
		Move();
		Draw();
	}
}

