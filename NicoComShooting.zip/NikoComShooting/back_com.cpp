#include "pch.h"
#include "back_com.h"

//-----------�R���X�g���N�^---------------//
BACK_COM::BACK_COM()
{
	x	= 690;
	y	= 100;
	end_x =1000;
	end_y =370;
    color = GetColor( 240 , 240 , 240 );
}


//-----------Draw�֐�---------------//
void BACK_COM::Draw()
{
	
	DrawBox(x, y, end_x, end_y, color, true);
}


//-----------All�֐�---------------//
void BACK_COM::All()
{
	Draw();
}

