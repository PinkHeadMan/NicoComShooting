#include "pch.h"
#include "frame.h"

//-----------�R���X�g���N�^---------------//
FRAME::FRAME()
{
	
	int gh_temp	= LoadGraph("images/frame.png");
	GetGraphSize(gh_temp, &width, &height);
	DeleteGraph(gh_temp);

	gh	= LoadGraph("images/frame.png");
	x	= MARGIN;
	y	= MARGIN;
}


//-----------Draw�֐�---------------//
void FRAME::Draw()
{
	DrawGraph(x, y, gh, true);

	/* �摜�T�C�Y��\��
	char hoge[10];
	itoa(width,hoge,10);
	DrawString(x, y, hoge, GetColor( 255, 255, 255 ));
	itoa(height,hoge,10);
	DrawString(x, y+100, hoge, GetColor( 255, 255, 255 ));
	*/
}


//-----------Move�֐�---------------//
void FRAME::Move()
{
	//�ړ��Ȃ�
}


//-----------All�֐�---------------//
void FRAME::All()
{
	Draw();
}

