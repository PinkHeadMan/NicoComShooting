#include "pch.h"
#include "smoke.h"

//-----------�R���X�g���N�^---------------//
SMOKE::SMOKE()
{
	gh = LoadGraph("images/black.png");
	x=y=MARGIN;
}


//-----------Draw�֐�---------------//
void SMOKE::Draw()
{
	SetDrawBlendMode(DX_BLENDMODE_ALPHA, 140);
	DrawGraph(x,y,gh,FALSE);
	SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
}


//-----------Move�֐�---------------//
void SMOKE::Move()
{
	
}


//-----------All�֐�---------------//
void SMOKE::All()
{
	Draw();
	Move();
}

